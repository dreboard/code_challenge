# Code Challenge 
A Simple PHP program to demonstrate Object Oriented Programming(OOP)
* [Live Site](http://challenge.dev-php.site)
###Features
* Reading external files with the Standard PHP Library
* Object Oriented Programming


####Additional
* Unit Tesing and Code Coverage
* PHPDocumentor Reports